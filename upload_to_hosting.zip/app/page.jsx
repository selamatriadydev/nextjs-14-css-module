const Homepage = () => {
  return (
    <div>Homepage</div>
  )
}

export default Homepage